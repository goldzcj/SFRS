#include <iostream>
#include <iomanip>
#include "final_function.h"
using namespace std; 

//const string facility [4] = {"AVR","GYMNASIUM", "ROOM 1", "ROOM 2"};
//const string month [12] = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"};

//gotoxy (45,4); will be the default
//FUNCTION CALLING FOR MENU OF CREATING RESERVATION
void create_reserve();
//FUNCTION CALLING FOR MENU OF DELETING RESERVATION
void manage_reserve();

void Box(int x1, int x2, int y1, int y2) // this function is for the design of the entire console
{ 
            for (x1=x1;y1<=y2;y1++){
                gotoxy(y1,x1);cout <<"o";
                gotoxy(y1,x2);cout <<"o";
            }
            for (y1=x1;x1<=x2;x1++){
                gotoxy(y2,x1);cout <<"o";
                gotoxy(y1,x1);cout <<"o";
            }
}



int main()
{

	int main_choice;	
do {
	system ("color 70");
	//USE WHILE LOOP TO CHECK IF THE INPUT IS INTEGER
	//IF INPUT IS INTEGER IT WILL BREAK AND PROCEED TO THE NEXT PROCEDURE
  	while (true) {	
	  
	  	system ("cls");
	  		//Box(5,28,5,83);
			gotoxy (40,4);  cout << "SCHOOL FACILITY RESERVATION SYSTEM "; 
			gotoxy (45,7); cout << "(1) - Create Reservation \n"; 
			gotoxy (45,8); cout << "(2) - Manage Reservation \n"; 
			gotoxy (45,9); cout << "(3) - Exit. \n";
        	gotoxy (45,11); cout << "Enter an your choice: ";
        	cin >> main_choice;
        
	//THIS PART OF CODE CHECKS IF THE INPUT IS AN INTEGER
	
        if (cin.fail()) {  //CIN.FAIL JUST MEANS IF THE INPUT IS WRONG LIKE CHARACTER INSTEAD OF AN INTEGER
            // Invalid input (non-integer)
            cin.clear(); // Clear error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
            	  	system ("cls");
            cout << "Invalid input. Please enter an integer.\n";
			cout <<  system ("pause>0");
        } else {
            // Input is a valid integer
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear any additional characters in the input buffer
            break;
        }
    }
    
    
	switch (main_choice)
	{
		
		//CREATE RESERVATIONS
		case 1 : system ("cls");
		{
			gotoxy (45,4); cout << "You chose Create Reservation\n"; 
			gotoxy (45,5); cout <<  "Press any key to Proceed"; 
			system ("pause>0");
			create_reserve();

		}break;
		
		//MANAGE RESERVATIONS 
		case 2 : system ("cls");
		{
			gotoxy (45,4);cout  << "You chose Manage Reservation\n"; 
			gotoxy (45,5);cout  << "Press any key to Proceed"; 
			system ("pause>0"); 
			manage_reserve();
			
		}break;
		
		//EXIT 	
		case 3 : system ("cls");
		{
			gotoxy (45,4); cout << "Exiting Program...";
			system ("pause>0");
			exit (0);
			
		}break; 
		
		default : system ("cls");
		{
			
			gotoxy (45,4); cout << "Invalid Input. Try Again";
			gotoxy (45,5); system ("pause"); 
			
		}
	}

}while (main_choice != 3);	
}





void create_reserve()
{
	int response; 
	int create_reservation_choice;
	do {	

	while (true) {	
		system ("cls");		
		gotoxy (45,4); cout <<"Choose Occupation "; 
		gotoxy (45,6); cout <<"(1) - Student "; 
	 	gotoxy (45,7); cout <<"(2) - Professor "; 
	    gotoxy (45,8); cout <<"(3) - Return to Main Menu";
		gotoxy (45,10); cout << "Input your choice: ";  
		cin >> create_reservation_choice;
		chooseProfession(create_reservation_choice);	
		
		
        if (cin.fail()) {
            // Invalid input (non-integer)
            cin.clear(); // Clear error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
            system ("cls");
            gotoxy (45,4); cout << "Invalid input. Please enter an integer.\n";
            system ("pause>0"); 
        } else {
            // Input is a valid integer
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear any additional characters in the input buffer
            break;
        }  
    }
	


	switch (create_reservation_choice)
	{

//STUDENT------------------------------------------------
		case 1: system ("cls");{
		gotoxy (45,4);cout << "You've chosen Student \n";
		gotoxy (45,5);cout << "Click Enter to continue";
		system ("pause>0"); 
		student_info();		
		system ("cls");
		gotoxy (45,4); cout << "THESE ARE THE CURRENT RESERVATIONS.\n\n";
		view_reservations_justshow();
		
		
   do {
   	
        system("cls");
        reservation();
		
		system ("cls"); 
        gotoxy (45,4);cout  << "Do you want to reserve another? \n";
        gotoxy (45,6);cout  << "(1) - Yes \n";
        gotoxy (45,7);cout  << "(2) - No \n";
        gotoxy (45,9);cout  << "Input your choice: ";
        cin >> response;

        if (cin.fail()) {
            // Invalid input (non-integer)
            cin.clear(); // Clear error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
            system("cls");
            gotoxy (45,4);cout << "Invalid input. Please enter an integer.\n";
            system("pause>0");
        } else {
            // Input is a valid integer
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear any additional characters in the input buffer
            if (response == 1) {
                // Go back to reservation() if the user inputted 1
                continue;
            } else if (response == 2) {
                // Break the loop if the user inputted 2
                break;
            } else {
                system("cls");
                gotoxy (45,4); cout << "Invalid choice. Please enter either 1 or 2.\n";
                system("pause>0");
            }
            
            
        }
        
        
    } while (true);
    
  		system ("cls");   	
		//view_reservations();
		
		return; 
		
	}break; 
		
		
//PROFESSOR------------------------------------------------		
		case 2:system ("cls");{
        gotoxy (45,4);cout << "You've chosen Professor \n";
		gotoxy (45,5);cout << "Click Enter to continue"; 	
		professor_info(); 
		//cout << endl<<endl;
		system ("cls");
		gotoxy (45,4); cout << "THESE ARE THE CURRENT RESERVATIONS.\n\n";
		view_reservations_justshow();
	//	reservation();


   do {
   	
        system("cls");
        reservation();
		
		system ("cls"); 
        gotoxy (45,4);cout  << "Do you want to reserve another? \n";
        gotoxy (45,6);cout  << "(1) - Yes \n";
        gotoxy (45,7);cout  <<"(2) - No \n";
        gotoxy (45,9);cout  << "Input your choice: ";
        cin >> response;


       if (cin.fail()) {
            // Invalid input (non-integer)
            cin.clear(); // Clear error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
            system("cls");
            gotoxy (45,4);cout << "Invalid input. Please enter an integer.\n";
            system("pause>0");
        } else {
            // Input is a valid integer
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear any additional characters in the input buffer
            if (response == 1) {
                // Go back to reservation() if the user inputted 1
                continue;
            } else if (response == 2) {
                // Break the loop if the user inputted 2
                break;
            } else {
                system("cls");
                gotoxy (45,4); cout << "Invalid choice. Please enter either 1 or 2.\n";
                system("pause>0");
            }
            
        }
        
        
        } while(true);
  		system ("cls");   	
		//view_reservations();
		return; 
		}break; 
		
		
		case 3: system ("cls");{
			gotoxy (45,4); cout << "Returning to Main Menu...";
			return; 	
		}break; 
		
		
		default : system ("cls");
		{
			gotoxy (45,4); cout << "Invalid Input. Try Again \n";
			system ("pause>0"); 
			
		}break;
		
		
	}
}while (create_reservation_choice != 3);

	
	
}


void manage_reserve()
{
		int manage_choice; 
	do 
	{
	
	while (true)
	{
	system("cls");		
	gotoxy (45,4); cout  << "MANAGE RESERVATIONS \n"; 
	gotoxy (45,6); cout << "(1) - DISPLAY ALL RESERVATIONS \n";
	gotoxy (45,7); cout << "(2) - DELETE A RESERVATION/S \n";	
	gotoxy (45,8); cout << "(3) - Return to Main Menu\n";
	gotoxy (45,10);cout << "Enter your choice: ";
	cin >> manage_choice; 
	
	 	    if (cin.fail() || manage_choice < 1 || manage_choice > 3) 
			 {
            cin.clear(); // Clear error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
            system("cls");
            gotoxy (45,4); cout << "Invalid input. Please enter a valid integer between 1 and 3.\n";
            system("pause>0");
         	}   
         	else
			{
            // Input is a valid integer
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear any additional characters in the input buffer
            break;
        	}	
	}
		
		
		
		switch (manage_choice)
		{
			
			case 1:system("cls");{
			
			gotoxy (45,4); cout << "DISPLAY RESERVATIONS\n";
			view_reservations_justshow();
		
				
			}break;
			
			case 2:system("cls");{
			
			
			gotoxy (45,4); cout << "DELETE RESERVATION/S \n"; 
 			deleteline();			
			 
				
			}break;
			
			
			case 3:system("cls");{
			gotoxy (45,4); cout << "Returning to Main Menu"; 
			system ("pause>0");
				
			}break;		

		default : system ("cls");
		{
			gotoxy (45,4); cout <<  "Invalid Input. Try Again \n";
			system ("pause>0"); 

			
		}break; 
			
		}
		
	}while (manage_choice!=3); 
	
	
	
}





